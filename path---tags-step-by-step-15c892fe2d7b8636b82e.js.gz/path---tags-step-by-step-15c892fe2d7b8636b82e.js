webpackJsonp([117287309905404],{

/***/ 1669:
/***/ (function(module, exports) {

	module.exports = {"data":{"allMarkdownRemark":{"totalCount":1,"edges":[{"node":{"fields":{"slug":"/2019-06-06-huong-dan-publish-package-len-npm"},"excerpt":"Package là gì, và module là gì Cài đặt Kiểm tra Publish Package là gì, và module là gì Npm sẽ phân biệt 2 khái niệm  package  và  module…","timeToRead":3,"frontmatter":{"title":"Hướng dẫn tạo một package, publish nó lên npm","tags":["javascript","step-by-step"],"date":"2019-06-06","desc":"Nếu bạn có một package nào đó muốn chia sẽ cùng mọi người trên npm, thì đây là cách bạn publish package make-by-me như vậy lên npm"}}}]}},"pathContext":{"post":[{"frontmatter":{"title":"Hướng dẫn tạo một package, publish nó lên npm","desc":"Nếu bạn có một package nào đó muốn chia sẽ cùng mọi người trên npm, thì đây là cách bạn publish package make-by-me như vậy lên npm","type":"post","category":null,"tags":["javascript","step-by-step"],"date":"2019-06-06","cover":""},"fields":{"slug":"/2019-06-06-huong-dan-publish-package-len-npm"}}],"tag":"step-by-step"}}

/***/ })

});
//# sourceMappingURL=path---tags-step-by-step-15c892fe2d7b8636b82e.js.map