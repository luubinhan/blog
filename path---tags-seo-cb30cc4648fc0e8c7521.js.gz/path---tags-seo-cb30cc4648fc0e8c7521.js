webpackJsonp([213241352514491],{

/***/ 1668:
/***/ (function(module, exports) {

	module.exports = {"data":{"allMarkdownRemark":{"totalCount":1,"edges":[{"node":{"fields":{"slug":"/2016-11-07-wordpress-va-google-accelerated-mobile-pages-amp-tat-ca-nhung-gi-ban-can-biet"},"excerpt":"Google Accelerated Mobile Pages - Nó là gì? Ưu điểm của Google AMP Cài đặt Google AMP for Wordpress Trong giới làm web ai cũng biết một điều…","timeToRead":3,"frontmatter":{"title":"Wordpress và Google Accelerated Mobile Pages (AMP): Tất cả những gì bạn cần biết","tags":["wordpress","SEO"],"date":"2016-11-07","desc":"Trong giới làm web ai cũng biết một điều Speed is King. Dân tình thích mua một gói hàng trên mạng và phải được giao ngay lập tức, ít nhất là trong 24g, chậm trễ vài ngày là thấy hông vui, thích post tấm hình lên facebook có triệu triệu lượt người like ngay lập tức."}}}]}},"pathContext":{"post":[{"frontmatter":{"title":"Wordpress và Google Accelerated Mobile Pages (AMP): Tất cả những gì bạn cần biết","desc":"Trong giới làm web ai cũng biết một điều Speed is King. Dân tình thích mua một gói hàng trên mạng và phải được giao ngay lập tức, ít nhất là trong 24g, chậm trễ vài ngày là thấy hông vui, thích post tấm hình lên facebook có triệu triệu lượt người like ngay lập tức.","type":"post","category":"wordpress","tags":["wordpress","SEO"],"date":"2016-11-07","cover":""},"fields":{"slug":"/2016-11-07-wordpress-va-google-accelerated-mobile-pages-amp-tat-ca-nhung-gi-ban-can-biet"}}],"tag":"SEO"}}

/***/ })

});
//# sourceMappingURL=path---tags-seo-cb30cc4648fc0e8c7521.js.map