webpackJsonp([134928267902561],{

/***/ 1660:
/***/ (function(module, exports) {

	module.exports = {"data":{"allMarkdownRemark":{"totalCount":1,"edges":[{"node":{"fields":{"slug":"/2019-03-31-huong-dan-7-thu-thuat-trong-gatsby"},"excerpt":"Lấy Ngày build gần nhất Ngày chỉnh sửa gần nhất Cùng source, khác Queries Previous/Next Bài viết ngẫu nhiên Mặc định mở trình duyệt Sử dụng…","timeToRead":5,"frontmatter":{"title":"7 thủ thuật trong gatsby","tags":["gatsby"],"date":"2019-03-31","desc":"Tập hợp những thủ thuật khi làm việc với gatsby"}}}]}},"pathContext":{"post":[{"frontmatter":{"title":"7 thủ thuật trong gatsby","desc":"Tập hợp những thủ thuật khi làm việc với gatsby","type":"post","category":null,"tags":["gatsby"],"date":"2019-03-31","cover":""},"fields":{"slug":"/2019-03-31-huong-dan-7-thu-thuat-trong-gatsby"}}],"tag":"gatsby"}}

/***/ })

});
//# sourceMappingURL=path---tags-gatsby-39c92a812255f25524aa.js.map