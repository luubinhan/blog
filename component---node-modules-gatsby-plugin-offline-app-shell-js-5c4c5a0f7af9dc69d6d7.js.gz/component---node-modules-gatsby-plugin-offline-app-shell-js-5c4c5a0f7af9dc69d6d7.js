webpackJsonp([99219681209289],{

/***/ 1365:
/***/ (function(module, exports, __webpack_require__) {

	"use strict";
	
	exports.__esModule = true;
	
	var _classCallCheck2 = __webpack_require__(5);
	
	var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);
	
	var _possibleConstructorReturn2 = __webpack_require__(7);
	
	var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);
	
	var _inherits2 = __webpack_require__(6);
	
	var _inherits3 = _interopRequireDefault(_inherits2);
	
	var _react = __webpack_require__(1);
	
	var _react2 = _interopRequireDefault(_react);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	var AppShell = function (_React$Component) {
	  (0, _inherits3.default)(AppShell, _React$Component);
	
	  function AppShell() {
	    (0, _classCallCheck3.default)(this, AppShell);
	    return (0, _possibleConstructorReturn3.default)(this, _React$Component.apply(this, arguments));
	  }
	
	  AppShell.prototype.render = function render() {
	    return _react2.default.createElement("div", null);
	  };
	
	  return AppShell;
	}(_react2.default.Component);
	
	exports.default = AppShell;

/***/ })

});
//# sourceMappingURL=component---node-modules-gatsby-plugin-offline-app-shell-js-5c4c5a0f7af9dc69d6d7.js.map