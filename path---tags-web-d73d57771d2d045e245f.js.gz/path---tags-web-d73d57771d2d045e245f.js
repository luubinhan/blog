webpackJsonp([198727112194860],{

/***/ 1683:
/***/ (function(module, exports) {

	module.exports = {"data":{"allMarkdownRemark":{"totalCount":2,"edges":[{"node":{"fields":{"slug":"/2018-07-01-huong-dan-cai-dat-ten-mien-cho-githubpage-su-dung-godady"},"excerpt":"Đăng nhập vào Goddady, mở tab My Products, chọn nút  Manage Cuộn xuống ở dưới cuối trang, click link  Manage DNS Hàng type  A , nhập vào IP…","timeToRead":1,"frontmatter":{"title":"Hướng dẫn setup tên miền GoDaddy với Github Page","tags":["web","dns","githubpage"],"date":"2018-07-01","desc":"Hướng dẫn cầu hình tên miền trên GoDaddy để sử dụng với Github page"}}},{"node":{"fields":{"slug":"/2017-10-03-thiet-ke-an-tuong-vs-thiet-ke-thuc-te-bai-hoc-thuc-te"},"excerpt":"Thiết kế tốt hơn phải giải quyết một vấn đề thực tế của người sử dụng Product Manager và Lập trình viên luôn là bạn tốt nhất Bạn đang thiết…","timeToRead":9,"frontmatter":{"title":"Thiết kế tuyệt đẹp vs. Thực tế: bài học từ Facebook","tags":["ux-ui","design","web"],"date":"2017-10-03","desc":"Bài viết dịch lại của một anh làm product design cho facebook đăng tải trên medium"}}}]}},"pathContext":{"post":[{"frontmatter":{"title":"Hướng dẫn setup tên miền GoDaddy với Github Page","desc":"Hướng dẫn cầu hình tên miền trên GoDaddy để sử dụng với Github page","type":"post","category":null,"tags":["web","dns","githubpage"],"date":"2018-07-01","cover":""},"fields":{"slug":"/2018-07-01-huong-dan-cai-dat-ten-mien-cho-githubpage-su-dung-godady"}},{"frontmatter":{"title":"Thiết kế tuyệt đẹp vs. Thực tế: bài học từ Facebook","desc":"Bài viết dịch lại của một anh làm product design cho facebook đăng tải trên medium","type":"post","category":"ux-ui","tags":["ux-ui","design","web"],"date":"2017-10-03","cover":""},"fields":{"slug":"/2017-10-03-thiet-ke-an-tuong-vs-thiet-ke-thuc-te-bai-hoc-thuc-te"}}],"tag":"web"}}

/***/ })

});
//# sourceMappingURL=path---tags-web-d73d57771d2d045e245f.js.map