webpackJsonp([73546786215923],{

/***/ 1661:
/***/ (function(module, exports) {

	module.exports = {"data":{"allMarkdownRemark":{"totalCount":1,"edges":[{"node":{"fields":{"slug":"/2018-10-16-huong-dan-progressive-web-app-cho-nguoi-moi-bat-dau"},"excerpt":"Giới thiệu Đánh giá bằng Lighthouse Thêm web app manifest Offline mức căn bản Đăng ký service worker Xử lý network request bị fail Service…","timeToRead":15,"frontmatter":{"title":"Làm Progressive Web App cho người mới","tags":["pwa","mobile-web-specialist"],"date":"2018-10-16","desc":"Cùng mình đú trend, dựng một Progressive Web App theo chỉ dẫn của Google"}}}]}},"pathContext":{"post":[{"frontmatter":{"title":"Làm Progressive Web App cho người mới","desc":"Cùng mình đú trend, dựng một Progressive Web App theo chỉ dẫn của Google","type":"post","category":null,"tags":["pwa","mobile-web-specialist"],"date":"2018-10-16","cover":""},"fields":{"slug":"/2018-10-16-huong-dan-progressive-web-app-cho-nguoi-moi-bat-dau"}}],"tag":"pwa"}}

/***/ })

});
//# sourceMappingURL=path---tags-pwa-dfc9f89418d9894f9512.js.map