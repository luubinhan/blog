webpackJsonp([72082381743961],{

/***/ 1659:
/***/ (function(module, exports) {

	module.exports = {"data":{"allMarkdownRemark":{"totalCount":1,"edges":[{"node":{"fields":{"slug":"/2018-07-01-huong-dan-cai-dat-ten-mien-cho-githubpage-su-dung-godady"},"excerpt":"Đăng nhập vào Goddady, mở tab My Products, chọn nút  Manage Cuộn xuống ở dưới cuối trang, click link  Manage DNS Hàng type  A , nhập vào IP…","timeToRead":1,"frontmatter":{"title":"Hướng dẫn setup tên miền GoDaddy với Github Page","tags":["web","dns","githubpage"],"date":"2018-07-01","desc":"Hướng dẫn cầu hình tên miền trên GoDaddy để sử dụng với Github page"}}}]}},"pathContext":{"post":[{"frontmatter":{"title":"Hướng dẫn setup tên miền GoDaddy với Github Page","desc":"Hướng dẫn cầu hình tên miền trên GoDaddy để sử dụng với Github page","type":"post","category":null,"tags":["web","dns","githubpage"],"date":"2018-07-01","cover":""},"fields":{"slug":"/2018-07-01-huong-dan-cai-dat-ten-mien-cho-githubpage-su-dung-godady"}}],"tag":"dns"}}

/***/ })

});
//# sourceMappingURL=path---tags-dns-85e03b5315eb1f15b7a7.js.map