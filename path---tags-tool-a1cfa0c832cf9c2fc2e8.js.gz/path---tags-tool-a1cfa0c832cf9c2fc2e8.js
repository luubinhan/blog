webpackJsonp([12781602048153],{

/***/ 1679:
/***/ (function(module, exports) {

	module.exports = {"data":{"allMarkdownRemark":{"totalCount":1,"edges":[{"node":{"fields":{"slug":"/2019-11-23-thiet-dat-eslint"},"excerpt":"ESLint có thể cài global, nhưng mình thấy nên cài trên từng project sẽ tiện hơn khi phải mang đi mang lại. Đây là những package cần thiết…","timeToRead":2,"frontmatter":{"title":"Thiết đặt ESLint cho dự án React","tags":["thu-thuat","tool"],"date":"2019-11-23","desc":"Các thiết đặt và công cụ cần thiết để eslint hoạt động tốt trong dự án React"}}}]}},"pathContext":{"post":[{"frontmatter":{"title":"Thiết đặt ESLint cho dự án React","desc":"Các thiết đặt và công cụ cần thiết để eslint hoạt động tốt trong dự án React","type":"post","category":null,"tags":["thu-thuat","tool"],"date":"2019-11-23","cover":""},"fields":{"slug":"/2019-11-23-thiet-dat-eslint"}}],"tag":"tool"}}

/***/ })

});
//# sourceMappingURL=path---tags-tool-a1cfa0c832cf9c2fc2e8.js.map