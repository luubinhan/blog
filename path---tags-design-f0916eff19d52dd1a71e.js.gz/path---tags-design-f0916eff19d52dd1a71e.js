webpackJsonp([65951750749414],{

/***/ 1652:
/***/ (function(module, exports) {

	module.exports = {"data":{"allMarkdownRemark":{"totalCount":1,"edges":[{"node":{"fields":{"slug":"/2017-10-03-thiet-ke-an-tuong-vs-thiet-ke-thuc-te-bai-hoc-thuc-te"},"excerpt":"Thiết kế tốt hơn phải giải quyết một vấn đề thực tế của người sử dụng Product Manager và Lập trình viên luôn là bạn tốt nhất Bạn đang thiết…","timeToRead":9,"frontmatter":{"title":"Thiết kế tuyệt đẹp vs. Thực tế: bài học từ Facebook","tags":["ux-ui","design","web"],"date":"2017-10-03","desc":"Bài viết dịch lại của một anh làm product design cho facebook đăng tải trên medium"}}}]}},"pathContext":{"post":[{"frontmatter":{"title":"Thiết kế tuyệt đẹp vs. Thực tế: bài học từ Facebook","desc":"Bài viết dịch lại của một anh làm product design cho facebook đăng tải trên medium","type":"post","category":"ux-ui","tags":["ux-ui","design","web"],"date":"2017-10-03","cover":""},"fields":{"slug":"/2017-10-03-thiet-ke-an-tuong-vs-thiet-ke-thuc-te-bai-hoc-thuc-te"}}],"tag":"design"}}

/***/ })

});
//# sourceMappingURL=path---tags-design-f0916eff19d52dd1a71e.js.map